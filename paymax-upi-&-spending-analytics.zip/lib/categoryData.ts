import { CategoryId, CategoryMeta } from '@/types/upi';

export const CATEGORIES: Record<CategoryId, CategoryMeta> = {
  petroleum: {
    id: 'petroleum',
    name: 'Petroleum & Fuel',
    iconName: 'Fuel',
    color: '#f59e0b', // Amber
    bgColor: 'bg-amber-50',
    borderColor: 'border-amber-200',
    textColor: 'text-amber-700',
    defaultBudget: 6000,
    description: 'Petrol, diesel, EV charging, and oil station payments',
  },
  groceries: {
    id: 'groceries',
    name: 'Groceries & Supermarket',
    iconName: 'ShoppingCart',
    color: '#10b981', // Emerald
    bgColor: 'bg-emerald-50',
    borderColor: 'border-emerald-200',
    textColor: 'text-emerald-700',
    defaultBudget: 8000,
    description: 'Supermarket, quick-commerce delivery, and staples',
  },
  food: {
    id: 'food',
    name: 'Food & Dining',
    iconName: 'Utensils',
    color: '#f43f5e', // Rose
    bgColor: 'bg-rose-50',
    borderColor: 'border-rose-200',
    textColor: 'text-rose-700',
    defaultBudget: 4500,
    description: 'Swiggy, Zomato, cafes, restaurants, and street food',
  },
  vegetables: {
    id: 'vegetables',
    name: 'Vegetables & Produce',
    iconName: 'Carrot',
    color: '#84cc16', // Lime
    bgColor: 'bg-lime-50',
    borderColor: 'border-lime-200',
    textColor: 'text-lime-700',
    defaultBudget: 3500,
    description: 'Local mandi, fruit vendors, and organic vegetable shops',
  },
  pharmacy: {
    id: 'pharmacy',
    name: 'Pharmacy & Health',
    iconName: 'Pill',
    color: '#06b6d4', // Cyan
    bgColor: 'bg-cyan-50',
    borderColor: 'border-cyan-200',
    textColor: 'text-cyan-700',
    defaultBudget: 3000,
    description: 'Medicines, diagnostic labs, and medical supplies',
  },
  utilities: {
    id: 'utilities',
    name: 'Utilities & Bills',
    iconName: 'Zap',
    color: '#6366f1', // Indigo
    bgColor: 'bg-indigo-50',
    borderColor: 'border-indigo-200',
    textColor: 'text-indigo-700',
    defaultBudget: 5000,
    description: 'Electricity, Broadband, Water, and DTH recharges',
  },
  shopping: {
    id: 'shopping',
    name: 'Shopping & Fashion',
    iconName: 'ShoppingBag',
    color: '#a855f7', // Purple
    bgColor: 'bg-purple-50',
    borderColor: 'border-purple-200',
    textColor: 'text-purple-700',
    defaultBudget: 7000,
    description: 'Amazon, Flipkart, apparel, electronics, and lifestyle',
  },
  transfer: {
    id: 'transfer',
    name: 'Bank Transfer & Friends',
    iconName: 'ArrowRightLeft',
    color: '#3b82f6', // Blue
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200',
    textColor: 'text-blue-700',
    defaultBudget: 10000,
    description: 'Peer-to-peer transfers, rent, and family payments',
  },
  other: {
    id: 'other',
    name: 'Other Expenses',
    iconName: 'MoreHorizontal',
    color: '#64748b', // Slate
    bgColor: 'bg-slate-50',
    borderColor: 'border-slate-200',
    textColor: 'text-slate-700',
    defaultBudget: 3000,
    description: 'Miscellaneous expenses',
  },
};
