export type CategoryId = 
  | 'petroleum'
  | 'groceries'
  | 'food'
  | 'vegetables'
  | 'pharmacy'
  | 'utilities'
  | 'shopping'
  | 'transfer'
  | 'other';

export interface CategoryMeta {
  id: CategoryId;
  name: string;
  iconName: string;
  color: string;
  bgColor: string;
  borderColor: string;
  textColor: string;
  defaultBudget: number;
  description: string;
}

export interface BankAccount {
  id: string;
  bankName: string;
  shortName: string;
  accountNumber: string; // e.g. "•••• 4821"
  ifscCode: string;
  accountType: 'Savings' | 'Current' | 'Salary';
  balance: number;
  vpa: string; // e.g. "sushil@okhdfcbank"
  isPrimary: boolean;
  colorGradient: string;
  cardLogoUrl?: string;
}

export interface Transaction {
  id: string;
  timestamp: string; // ISO date
  merchantName: string;
  upiId?: string;
  amount: number;
  type: 'debit' | 'credit';
  category: CategoryId;
  bankAccountId: string;
  bankName: string;
  status: 'success' | 'pending' | 'failed';
  note?: string;
  receiptNumber?: string;
  cashbackRewardId?: string;
}

export interface CategoryBudget {
  categoryId: CategoryId;
  limit: number;
}

export interface Reward {
  id: string;
  title: string;
  merchant: string;
  category: CategoryId;
  code: string;
  cashbackAmount: number;
  isScratched: boolean;
  dateAdded: string;
}

export interface Contact {
  id: string;
  name: string;
  phone: string;
  upiId: string;
  avatarColor: string;
  defaultCategory: CategoryId;
}
