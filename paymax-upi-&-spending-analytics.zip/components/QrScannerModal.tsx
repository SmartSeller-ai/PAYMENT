'use client';

import React, { useState } from 'react';
import { Camera, QrCode, Upload, X, Zap, CheckCircle2, ShieldCheck } from 'lucide-react';
import { CategoryId } from '@/types/upi';

interface PresetQr {
  name: string;
  vpa: string;
  amount: number;
  category: CategoryId;
  note: string;
  badge: string;
  badgeColor: string;
}

interface QrScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScanSuccess: (data: {
    merchantName: string;
    vpa: string;
    amount: number;
    category: CategoryId;
    note: string;
  }) => void;
}

const PRESET_QRS: PresetQr[] = [
  {
    name: 'HPCL Power Fuel Pump',
    vpa: 'hpcl.koramangala@icici',
    amount: 1500,
    category: 'petroleum',
    note: 'Petrol refill (Power 95)',
    badge: '⛽ Fuel QR',
    badgeColor: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  },
  {
    name: 'Blinkit Supermarket QR',
    vpa: 'blinkit.order@paytm',
    amount: 890,
    category: 'groceries',
    note: 'Groceries & Household order',
    badge: '🛒 Grocery QR',
    badgeColor: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  },
  {
    name: 'Fresh Vegetables Mandi Stall',
    vpa: 'greenfresh.veggies@ybl',
    amount: 350,
    category: 'vegetables',
    note: 'Fresh farm veggies & leafy greens',
    badge: '🥦 Vegetable Mandi',
    badgeColor: 'bg-lime-500/20 text-lime-400 border-lime-500/30',
  },
  {
    name: 'Apollo Pharmacy Counter',
    vpa: 'apollopharmacy@hdfcbank',
    amount: 980,
    category: 'pharmacy',
    note: 'Prescription medicines & wellness',
    badge: '💊 Pharmacy QR',
    badgeColor: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
  },
  {
    name: 'Swiggy Food Merchant',
    vpa: 'swiggy.pay@axisbank',
    amount: 520,
    category: 'food',
    note: 'Restaurant lunch order',
    badge: '🍲 Food QR',
    badgeColor: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
  },
];

export const QrScannerModal: React.FC<QrScannerModalProps> = ({
  isOpen,
  onClose,
  onScanSuccess,
}) => {
  const [selectedPreset, setSelectedPreset] = useState<PresetQr | null>(null);
  const [scanning, setScanning] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleSelectPreset = (qr: PresetQr) => {
    setSelectedPreset(qr);
    setScanning(true);
    setTimeout(() => {
      setScanning(false);
      onScanSuccess({
        merchantName: qr.name,
        vpa: qr.vpa,
        amount: qr.amount,
        category: qr.category,
        note: qr.note,
      });
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4 animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 text-white rounded-2xl w-full max-w-md overflow-hidden shadow-2xl relative">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-indigo-500/20 text-indigo-400">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base">Scan Merchant UPI QR</h3>
              <p className="text-xs text-slate-400">Point camera at BharatPE / GPay / Paytm QR</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Camera Viewfinder Area */}
        <div className="relative bg-black p-6 flex flex-col items-center justify-center min-h-[220px] overflow-hidden">
          {/* Animated Scanning Frame */}
          <div className="w-48 h-48 border-2 border-indigo-500/80 rounded-2xl relative flex items-center justify-center overflow-hidden shadow-[0_0_20px_rgba(99,102,241,0.3)]">
            <div className="absolute top-0 left-0 w-6 h-6 border-t-4 border-l-4 border-indigo-400 rounded-tl-lg" />
            <div className="absolute top-0 right-0 w-6 h-6 border-t-4 border-r-4 border-indigo-400 rounded-tr-lg" />
            <div className="absolute bottom-0 left-0 w-6 h-6 border-b-4 border-l-4 border-indigo-400 rounded-bl-lg" />
            <div className="absolute bottom-0 right-0 w-6 h-6 border-b-4 border-r-4 border-indigo-400 rounded-br-lg" />

            {/* Laser Line */}
            <div className="w-full h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent absolute top-0 animate-[bounce_2s_infinite]" />

            <div className="text-center p-2">
              <Camera className="w-8 h-8 text-indigo-400 mx-auto opacity-70 mb-1" />
              <p className="text-[11px] text-slate-400">Align QR Code inside box</p>
            </div>
          </div>

          <div className="mt-3 flex items-center gap-2 text-xs text-slate-400">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>Auto-detects merchant category & details</span>
          </div>
        </div>

        {/* Quick Sample Merchant QRs Picker */}
        <div className="p-4 bg-slate-900 border-t border-slate-800">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2.5">
            Or Quick Test Sample QRs:
          </p>

          <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
            {PRESET_QRS.map((qr, index) => (
              <button
                key={index}
                onClick={() => handleSelectPreset(qr)}
                disabled={scanning}
                className="w-full p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 flex items-center justify-between text-left transition group"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-xs text-white group-hover:text-indigo-300">
                      {qr.name}
                    </span>
                    <span
                      className={`text-[10px] font-medium px-1.5 py-0.5 rounded border ${qr.badgeColor}`}
                    >
                      {qr.badge}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">{qr.vpa}</p>
                </div>

                <div className="text-right">
                  <span className="font-bold text-xs text-emerald-400">
                    ₹{qr.amount}
                  </span>
                  <p className="text-[10px] text-indigo-400 underline flex items-center gap-0.5 mt-0.5">
                    Scan <CheckCircle2 className="w-3 h-3" />
                  </p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
