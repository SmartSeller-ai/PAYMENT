'use client';

import React from 'react';
import { 
  CreditCard, 
  PieChart as PieChartIcon, 
  Send, 
  Layers, 
  Gift, 
  Bot, 
  ShieldCheck, 
  ChevronDown,
  Building2,
  Wallet
} from 'lucide-react';
import { BankAccount } from '@/types/upi';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  banks: BankAccount[];
  primaryBank: BankAccount;
  onOpenBankModal: () => void;
  onOpenCheckBalanceModal: (bank: BankAccount) => void;
  totalMonthlySpent: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  banks,
  primaryBank,
  onOpenBankModal,
  onOpenCheckBalanceModal,
  totalMonthlySpent,
}) => {
  const tabs = [
    { id: 'pay', label: 'Pay & Send', icon: Send },
    { id: 'analytics', label: 'Spending Analytics', icon: PieChartIcon },
    { id: 'categories', label: 'Budgets & Categories', icon: Layers },
    { id: 'banks', label: 'Linked Banks', icon: Building2 },
    { id: 'rewards', label: 'Rewards & Offers', icon: Gift },
    { id: 'ai', label: 'AI Scanner & Advisor', icon: Bot },
  ];

  return (
    <header className="sticky top-0 z-30 bg-slate-50/90 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      {/* Top Branding & Quick Stats Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-3">
        {/* Logo & Brand */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-2xl flex items-center justify-center text-white font-bold text-xl shadow-sm">
            P
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-2xl font-bold tracking-tight text-slate-800">
                Pay<span className="text-indigo-600">Max</span>
              </h1>
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-indigo-100 text-indigo-700 uppercase tracking-wide">
                UPI 2.0
              </span>
            </div>
            <p className="text-xs text-slate-500 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" /> NPCI Verified
            </p>
          </div>
        </div>

        {/* Bank & Balance Bento Pill */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={onOpenBankModal}
            className="bg-white border border-slate-200 px-3.5 py-2 rounded-full flex items-center gap-2 shadow-xs hover:border-indigo-300 transition text-xs sm:text-sm"
          >
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-semibold text-slate-700 hidden sm:inline">{primaryBank?.shortName || 'Bank'}</span>
            <span className="font-mono text-slate-900 font-bold">{primaryBank?.vpa || 'user@paymax'}</span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          <button
            onClick={() => onOpenCheckBalanceModal(primaryBank)}
            className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-full font-bold text-xs sm:text-sm shadow-sm transition active:scale-95"
          >
            <Wallet className="w-4 h-4" />
            <span>Check Balance</span>
          </button>
        </div>
      </div>

      {/* Main Tab Navigation - Bento Style Bar */}
      <div className="bg-white/80 backdrop-blur border-t border-slate-100 px-4">
        <div className="max-w-7xl mx-auto flex items-center space-x-1.5 overflow-x-auto py-2 scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-slate-100/70 text-slate-600 hover:text-slate-900 hover:bg-slate-200/80'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};

