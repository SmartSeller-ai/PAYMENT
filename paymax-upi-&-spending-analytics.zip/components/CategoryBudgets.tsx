'use client';

import React, { useState } from 'react';
import { 
  Layers, 
  Fuel, 
  ShoppingCart, 
  Utensils, 
  Carrot, 
  Pill, 
  Zap, 
  ShoppingBag, 
  ArrowRightLeft, 
  MoreHorizontal,
  AlertTriangle,
  CheckCircle,
  Edit2,
  PlusCircle,
  X
} from 'lucide-react';
import { CategoryBudget, CategoryId, Transaction } from '@/types/upi';
import { CATEGORIES } from '@/lib/categoryData';

interface CategoryBudgetsProps {
  budgets: CategoryBudget[];
  transactions: Transaction[];
  onUpdateBudget: (categoryId: CategoryId, newLimit: number) => void;
}

export const CategoryBudgets: React.FC<CategoryBudgetsProps> = ({
  budgets,
  transactions,
  onUpdateBudget,
}) => {
  const [editingCategory, setEditingCategory] = useState<CategoryId | null>(null);
  const [editLimitValue, setEditLimitValue] = useState<string>('');

  // Calculate total spent per category
  const categorySpentMap: Record<CategoryId, number> = {
    petroleum: 0,
    groceries: 0,
    food: 0,
    vegetables: 0,
    pharmacy: 0,
    utilities: 0,
    shopping: 0,
    transfer: 0,
    other: 0,
  };

  transactions.forEach((tx) => {
    if (tx.type === 'debit') {
      categorySpentMap[tx.category] = (categorySpentMap[tx.category] || 0) + tx.amount;
    }
  });

  const handleStartEdit = (catId: CategoryId, currentLimit: number) => {
    setEditingCategory(catId);
    setEditLimitValue(currentLimit.toString());
  };

  const handleSaveEdit = (catId: CategoryId) => {
    const num = parseFloat(editLimitValue);
    if (!isNaN(num) && num >= 0) {
      onUpdateBudget(catId, num);
    }
    setEditingCategory(null);
  };

  const getCategoryIcon = (catId: CategoryId) => {
    switch (catId) {
      case 'petroleum': return Fuel;
      case 'groceries': return ShoppingCart;
      case 'food': return Utensils;
      case 'vegetables': return Carrot;
      case 'pharmacy': return Pill;
      case 'utilities': return Zap;
      case 'shopping': return ShoppingBag;
      case 'transfer': return ArrowRightLeft;
      default: return MoreHorizontal;
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-white rounded-3xl shadow-xs border border-slate-200 p-6 sm:p-7">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 mb-5 border-b border-slate-100">
          <div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <Layers className="w-5 h-5 text-indigo-600" />
              <span>Category Spending Limits & Budgets</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Set monthly budget caps for Petroleum, Groceries, Food, Vegetables, and Pharmacy
            </p>
          </div>
        </div>

        {/* Category Budget Cards List - Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {budgets.map((b) => {
            const catMeta = CATEGORIES[b.categoryId];
            const Icon = getCategoryIcon(b.categoryId);
            const spent = categorySpentMap[b.categoryId] || 0;
            const percentage = b.limit > 0 ? Math.min(100, Math.round((spent / b.limit) * 100)) : 0;
            const isExceeded = spent > b.limit;
            const isNearLimit = percentage >= 80 && !isExceeded;

            return (
              <div
                key={b.categoryId}
                className={`p-5 rounded-3xl border transition relative bg-white ${
                  isExceeded
                    ? 'border-rose-300 bg-rose-50/20'
                    : isNearLimit
                    ? 'border-amber-300 bg-amber-50/20'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                {/* Header */}
                <div className="flex items-center justify-between mb-3.5">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-2xl flex items-center justify-center text-white font-bold shadow-xs shrink-0"
                      style={{ backgroundColor: catMeta?.color || '#6366f1' }}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-900">{catMeta?.name}</h3>
                      <p className="text-[10px] text-slate-500 font-medium line-clamp-1">{catMeta?.description}</p>
                    </div>
                  </div>

                  {/* Edit Button */}
                  <button
                    onClick={() => handleStartEdit(b.categoryId, b.limit)}
                    className="p-2 rounded-xl text-slate-400 hover:text-indigo-600 hover:bg-slate-100 transition"
                    title="Change Budget Limit"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Edit Inline Form or Progress Display */}
                {editingCategory === b.categoryId ? (
                  <div className="mt-3 p-3 bg-indigo-50 border border-indigo-200 rounded-2xl space-y-2">
                    <label className="block text-[11px] font-bold text-indigo-900">
                      Set Monthly Limit (₹):
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        value={editLimitValue}
                        onChange={(e) => setEditLimitValue(e.target.value)}
                        className="w-full px-3 py-1.5 bg-white border border-indigo-300 rounded-xl text-xs font-bold text-slate-900 focus:outline-none"
                      />
                      <button
                        onClick={() => handleSaveEdit(b.categoryId)}
                        className="px-3 py-1.5 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700"
                      >
                        Save
                      </button>
                      <button
                        onClick={() => setEditingCategory(null)}
                        className="p-1.5 text-slate-400 hover:text-slate-600"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div>
                    {/* Figures */}
                    <div className="flex items-baseline justify-between mb-2">
                      <span className="text-xs font-medium text-slate-600">
                        Spent: <span className="text-base font-black text-slate-900">₹{spent.toLocaleString('en-IN')}</span>
                      </span>
                      <span className="text-xs text-slate-500 font-mono font-bold">
                        Limit: ₹{b.limit.toLocaleString('en-IN')}
                      </span>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          isExceeded
                            ? 'bg-rose-500'
                            : isNearLimit
                            ? 'bg-amber-500'
                            : 'bg-indigo-600'
                        }`}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>

                    {/* Status Alert */}
                    <div className="mt-3 flex items-center justify-between text-[11px]">
                      {isExceeded ? (
                        <span className="text-rose-600 font-bold flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5" /> Exceeded by ₹{(spent - b.limit).toLocaleString('en-IN')}
                        </span>
                      ) : isNearLimit ? (
                        <span className="text-amber-600 font-bold flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5" /> 80%+ budget used
                        </span>
                      ) : (
                        <span className="text-emerald-600 font-bold flex items-center gap-1">
                          <CheckCircle className="w-3.5 h-3.5" /> ₹{(b.limit - spent).toLocaleString('en-IN')} remaining
                        </span>
                      )}

                      <span className="font-extrabold text-slate-700">{percentage}%</span>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
