'use client';

import React, { useState } from 'react';
import { 
  Send, 
  QrCode, 
  User, 
  Building2, 
  CheckCircle2, 
  Fuel, 
  ShoppingCart, 
  Utensils, 
  Carrot, 
  Pill, 
  Zap, 
  ShoppingBag, 
  ArrowRightLeft, 
  MoreHorizontal,
  ChevronRight,
  Sparkles,
  Search,
  Wallet
} from 'lucide-react';
import { BankAccount, CategoryId, Contact } from '@/types/upi';
import { CATEGORIES } from '@/lib/categoryData';
import { INITIAL_CONTACTS } from '@/lib/mockData';

interface PaymentSectionProps {
  banks: BankAccount[];
  primaryBank: BankAccount;
  onInitiatePayment: (data: {
    merchantName: string;
    vpa: string;
    amount: number;
    category: CategoryId;
    bankAccountId: string;
    note: string;
  }) => void;
  onOpenQrScanner: () => void;
}

export const PaymentSection: React.FC<PaymentSectionProps> = ({
  banks,
  primaryBank,
  onInitiatePayment,
  onOpenQrScanner,
}) => {
  const [recipient, setRecipient] = useState<string>('');
  const [amount, setAmount] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<CategoryId>('petroleum');
  const [selectedBankId, setSelectedBankId] = useState<string>(primaryBank?.id || banks[0]?.id || '');
  const [note, setNote] = useState<string>('');
  const [searchContact, setSearchContact] = useState<string>('');
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);

  const selectedBank = banks.find((b) => b.id === selectedBankId) || primaryBank || banks[0];

  const handleSelectContact = (contact: Contact) => {
    setSelectedContact(contact);
    setRecipient(contact.upiId);
    setSelectedCategory(contact.defaultCategory);
  };

  const handleQuickCategorySelect = (catId: CategoryId) => {
    setSelectedCategory(catId);
  };

  const handlePay = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (!recipient || isNaN(numAmount) || numAmount <= 0) return;

    const merchantName = selectedContact
      ? selectedContact.name
      : recipient.includes('@')
      ? recipient.split('@')[0].toUpperCase().replace('.', ' ')
      : `UPI Transfer to ${recipient}`;

    onInitiatePayment({
      merchantName,
      vpa: recipient,
      amount: numAmount,
      category: selectedCategory,
      bankAccountId: selectedBankId,
      note: note || `${CATEGORIES[selectedCategory]?.name || 'UPI'} Payment`,
    });

    // Reset inputs
    setAmount('');
    setNote('');
  };

  // Helper for category icons
  const getCategoryIcon = (catId: CategoryId) => {
    switch (catId) {
      case 'petroleum': return Fuel;
      case 'groceries': return ShoppingCart;
      case 'food': return Utensils;
      case 'vegetables': return Carrot;
      case 'pharmacy': return Pill;
      case 'utilities': return Zap;
      case 'shopping': return ShoppingBag;
      case 'transfer': return ArrowRightLeft;
      default: return MoreHorizontal;
    }
  };

  const filteredContacts = INITIAL_CONTACTS.filter(
    (c) =>
      c.name.toLowerCase().includes(searchContact.toLowerCase()) ||
      c.upiId.toLowerCase().includes(searchContact.toLowerCase()) ||
      c.phone.includes(searchContact)
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in">
      {/* Main Payment Form Card (7 Cols) */}
      <div className="lg:col-span-7 space-y-6">
        <div className="bg-white rounded-3xl shadow-xs border border-slate-200 p-6 sm:p-7">
          <div className="flex items-center justify-between pb-4 mb-5 border-b border-slate-100">
            <div>
              <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2 tracking-tight">
                <Send className="w-5 h-5 text-indigo-600" />
                <span>Instant UPI Payment</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">Pay to any UPI ID, phone number or merchant QR</p>
            </div>

            <button
              onClick={onOpenQrScanner}
              type="button"
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2.5 rounded-2xl text-xs font-bold shadow-sm transition active:scale-95"
            >
              <QrCode className="w-4 h-4" />
              <span>Scan Any QR</span>
            </button>
          </div>

          <form onSubmit={handlePay} className="space-y-5">
            {/* Payee / VPA Input */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                Payee UPI ID or Mobile Number
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  placeholder="e.g. hpcl.pump@icici or 9876543210"
                  value={recipient}
                  onChange={(e) => {
                    setRecipient(e.target.value);
                    if (selectedContact && e.target.value !== selectedContact.upiId) {
                      setSelectedContact(null);
                    }
                  }}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition"
                />
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              </div>
            </div>

            {/* Amount Input */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                Amount (₹)
              </label>
              <div className="relative">
                <span className="absolute left-4 top-3.5 font-extrabold text-slate-400 text-xl">₹</span>
                <input
                  type="number"
                  required
                  min="1"
                  step="any"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 text-2xl font-black bg-slate-50 border border-slate-200 rounded-2xl text-slate-900 placeholder-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition"
                />
              </div>

              {/* Quick Amount Chips */}
              <div className="flex flex-wrap gap-2 mt-2.5">
                {[100, 500, 1000, 2000, 5000].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setAmount(amt.toString())}
                    className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 border border-slate-200 text-xs font-bold transition"
                  >
                    +₹{amt}
                  </button>
                ))}
              </div>
            </div>

            {/* Category Selector */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2 flex items-center justify-between">
                <span>Select Expense Category</span>
                <span className="text-[11px] text-indigo-600 font-semibold">Auto-tracks in Analytics</span>
              </label>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {Object.values(CATEGORIES).map((cat) => {
                  const Icon = getCategoryIcon(cat.id);
                  const isSelected = selectedCategory === cat.id;

                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => handleQuickCategorySelect(cat.id)}
                      className={`p-3 rounded-2xl border text-left flex items-center gap-3 transition ${
                        isSelected
                          ? `${cat.bgColor} ${cat.borderColor} border-2 ring-1`
                          : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <div
                        className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 text-white font-bold shadow-xs"
                        style={{ backgroundColor: cat.color }}
                      >
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="truncate">
                        <p className={`text-xs font-bold truncate ${isSelected ? cat.textColor : 'text-slate-800'}`}>
                          {cat.name.split('&')[0]}
                        </p>
                        <p className="text-[10px] text-slate-400 font-medium truncate">Budget: ₹{cat.defaultBudget}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Select Bank Account */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                Pay From Bank Account
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {banks.map((b) => {
                  const isSelected = selectedBankId === b.id;
                  return (
                    <button
                      key={b.id}
                      type="button"
                      onClick={() => setSelectedBankId(b.id)}
                      className={`p-3.5 rounded-2xl border text-left transition flex items-center justify-between ${
                        isSelected
                          ? 'border-indigo-600 bg-indigo-50/50 ring-2 ring-indigo-500/20'
                          : 'border-slate-200 bg-white hover:bg-slate-50'
                      }`}
                    >
                      <div>
                        <div className="flex items-center gap-1.5">
                          <Building2 className="w-3.5 h-3.5 text-slate-500" />
                          <span className="font-bold text-xs text-slate-900">{b.bankName}</span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">{b.accountNumber} ({b.accountType})</p>
                      </div>
                      <div className="text-right">
                        <span className="text-xs font-black text-emerald-600">
                          ₹{b.balance.toLocaleString('en-IN')}
                        </span>
                        {isSelected && <CheckCircle2 className="w-4 h-4 text-indigo-600 ml-auto mt-0.5" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Optional Note */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">
                Note / Remark (Optional)
              </label>
              <input
                type="text"
                placeholder="e.g. Fuel refill / Weekly grocery"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
              />
            </div>

            {/* Pay Button */}
            <button
              type="submit"
              disabled={!recipient || !amount || parseFloat(amount) <= 0}
              className="w-full py-4 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-sm rounded-2xl shadow-md transition active:scale-[0.99] disabled:opacity-50 disabled:shadow-none flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>Proceed to Pay {amount ? `₹${amount}` : ''} via UPI</span>
            </button>
          </form>
        </div>
      </div>

      {/* Side Column (5 Cols): Frequent Contacts & Category Highlights */}
      <div className="lg:col-span-5 space-y-6">
        {/* Quick Pay Merchants Bento Block */}
        <div className="bg-white rounded-3xl shadow-xs border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-3.5">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <User className="w-4 h-4 text-indigo-600" />
              <span>Quick Pay Merchants</span>
            </h3>
            <span className="text-xs text-indigo-600 font-bold">{INITIAL_CONTACTS.length} saved</span>
          </div>

          <div className="relative mb-3.5">
            <input
              type="text"
              placeholder="Search fuel, grocery, pharmacy..."
              value={searchContact}
              onChange={(e) => setSearchContact(e.target.value)}
              className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
          </div>

          <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
            {filteredContacts.map((contact) => {
              const catMeta = CATEGORIES[contact.defaultCategory];
              const Icon = getCategoryIcon(contact.defaultCategory);

              return (
                <button
                  key={contact.id}
                  onClick={() => handleSelectContact(contact)}
                  className="w-full p-3 rounded-2xl bg-slate-50 hover:bg-indigo-50/70 border border-slate-100 hover:border-indigo-200 flex items-center justify-between text-left transition group"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-9 h-9 rounded-xl ${contact.avatarColor} text-white font-bold flex items-center justify-center text-xs shadow-xs`}
                    >
                      {contact.name.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-bold text-xs text-slate-900 group-hover:text-indigo-700">
                        {contact.name}
                      </h4>
                      <p className="text-[11px] text-slate-500">{contact.upiId}</p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span
                      className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md ${catMeta?.bgColor} ${catMeta?.textColor}`}
                    >
                      <Icon className="w-3 h-3" />
                      {catMeta?.name.split(' ')[0]}
                    </span>
                    <p className="text-[10px] text-indigo-600 font-bold group-hover:underline mt-0.5">
                      Pay <ChevronRight className="w-3 h-3 inline" />
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Category Cashback Highlights Bento Banner */}
        <div className="bg-slate-900 rounded-3xl p-6 text-white shadow-md relative overflow-hidden border border-slate-800">
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold mb-2">
            <Sparkles className="w-4 h-4" />
            <span>Category Cashback Offers</span>
          </div>

          <h3 className="font-black text-lg mb-1">Fuel & Grocery Rewards</h3>
          <p className="text-xs text-slate-300 mb-4 leading-relaxed">
            Pay HPCL, IOCL, Blinkit, Apollo Pharmacy via PayMax UPI & get up to ₹100 instant cashback scratch cards!
          </p>

          <div className="grid grid-cols-3 gap-2.5 text-center text-xs font-bold">
            <div className="p-2.5 bg-slate-800/90 rounded-2xl border border-slate-700">
              <span className="text-amber-400 block text-base font-black">₹50</span>
              <span className="text-[10px] text-slate-400 font-medium">Petroleum</span>
            </div>
            <div className="p-2.5 bg-slate-800/90 rounded-2xl border border-slate-700">
              <span className="text-emerald-400 block text-base font-black">₹35</span>
              <span className="text-[10px] text-slate-400 font-medium">Groceries</span>
            </div>
            <div className="p-2.5 bg-slate-800/90 rounded-2xl border border-slate-700">
              <span className="text-cyan-400 block text-base font-black">₹100</span>
              <span className="text-[10px] text-slate-400 font-medium">Pharmacy</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
