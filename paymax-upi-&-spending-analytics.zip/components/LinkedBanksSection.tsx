'use client';

import React, { useState } from 'react';
import { 
  Building2, 
  ShieldCheck, 
  Plus, 
  CheckCircle2, 
  Wallet, 
  CreditCard, 
  Trash2, 
  ArrowUpRight,
  ChevronRight,
  PlusCircle
} from 'lucide-react';
import { BankAccount } from '@/types/upi';

interface LinkedBanksSectionProps {
  banks: BankAccount[];
  primaryBank: BankAccount;
  onSelectPrimaryBank: (bankId: string) => void;
  onOpenCheckBalanceModal: (bank: BankAccount) => void;
  onAddNewBank: (newBank: Omit<BankAccount, 'id'>) => void;
}

const AVAILABLE_BANKS = [
  { name: 'HDFC Bank', short: 'HDFC', ifsc: 'HDFC0000', color: 'from-blue-700 via-indigo-800 to-slate-900' },
  { name: 'State Bank of India', short: 'SBI', ifsc: 'SBIN0000', color: 'from-sky-600 via-blue-700 to-indigo-900' },
  { name: 'ICICI Bank', short: 'ICICI', ifsc: 'ICIC0000', color: 'from-orange-600 via-amber-700 to-stone-900' },
  { name: 'Axis Bank', short: 'AXIS', ifsc: 'UTIB0000', color: 'from-pink-700 via-rose-800 to-slate-900' },
  { name: 'Bank of Baroda', short: 'BOB', ifsc: 'BARB0000', color: 'from-orange-500 via-amber-600 to-slate-900' },
  { name: 'Kotak Mahindra Bank', short: 'KOTAK', ifsc: 'KKBK0000', color: 'from-red-600 via-rose-700 to-slate-900' },
  { name: 'Punjab National Bank', short: 'PNB', ifsc: 'PUNB0000', color: 'from-purple-600 via-indigo-800 to-slate-900' },
];

export const LinkedBanksSection: React.FC<LinkedBanksSectionProps> = ({
  banks,
  primaryBank,
  onSelectPrimaryBank,
  onOpenCheckBalanceModal,
  onAddNewBank,
}) => {
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [selectedBankTemplate, setSelectedBankTemplate] = useState(AVAILABLE_BANKS[0]);
  const [accountNumber, setAccountNumber] = useState<string>('9821');

  const handleAddBankSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddNewBank({
      bankName: selectedBankTemplate.name,
      shortName: selectedBankTemplate.short,
      accountNumber: `•••• ${accountNumber}`,
      ifscCode: `${selectedBankTemplate.ifsc}${Math.floor(1000 + Math.random() * 9000)}`,
      accountType: 'Savings',
      balance: Math.floor(15000 + Math.random() * 85000),
      vpa: `sushil@ok${selectedBankTemplate.short.toLowerCase()}`,
      isPrimary: false,
      colorGradient: selectedBankTemplate.color,
    });
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl shadow-xs border border-slate-200 p-6 sm:p-7">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <Building2 className="w-5 h-5 text-indigo-600" />
              <span>Multi-Bank Account Integration</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Manage your linked Indian bank accounts, check live balance & set default primary VPA
            </p>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2.5 rounded-2xl text-xs font-bold shadow-sm transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Link Another Bank</span>
          </button>
        </div>

        {/* Bank Cards Grid - Bento Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-5 mt-6">
          {banks.map((b) => (
            <div
              key={b.id}
              className={`rounded-3xl p-6 text-white shadow-md relative overflow-hidden bg-gradient-to-br ${b.colorGradient} border border-white/10`}
            >
              {/* Card Watermark */}
              <div className="absolute right-3 top-3 opacity-10">
                <Building2 className="w-32 h-32 text-white" />
              </div>

              {/* Top row */}
              <div className="flex items-center justify-between relative z-10 mb-6">
                <div>
                  <h3 className="font-extrabold text-lg tracking-wide">{b.bankName}</h3>
                  <p className="text-xs text-slate-300 font-medium">{b.accountType} Account • {b.accountNumber}</p>
                </div>

                {b.isPrimary ? (
                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 backdrop-blur-xs">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Primary UPI
                  </span>
                ) : (
                  <button
                    onClick={() => onSelectPrimaryBank(b.id)}
                    className="text-[10px] font-bold px-3 py-1 rounded-full bg-white/10 hover:bg-white/20 text-slate-200 border border-white/20 transition"
                  >
                    Set Primary
                  </button>
                )}
              </div>

              {/* VPA ID */}
              <div className="relative z-10 mb-5">
                <p className="text-[10px] text-slate-300 font-bold uppercase tracking-wider">UPI ID / VPA</p>
                <p className="font-mono text-base font-bold text-slate-100">{b.vpa}</p>
              </div>

              {/* Balance & Actions */}
              <div className="flex items-center justify-between relative z-10 pt-4 border-t border-white/15">
                <div>
                  <p className="text-[10px] text-slate-300 uppercase font-medium">Available Balance</p>
                  <p className="text-2xl font-black text-emerald-300">₹{b.balance.toLocaleString('en-IN')}</p>
                </div>

                <button
                  onClick={() => onOpenCheckBalanceModal(b)}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold transition backdrop-blur-xs"
                >
                  <Wallet className="w-4 h-4" />
                  <span>PIN Check</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Bank Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-fade-in">
          <div className="bg-white rounded-3xl w-full max-w-md p-7 border border-slate-200 shadow-2xl relative">
            <h3 className="font-bold text-lg text-slate-900 mb-1">Link New Indian Bank Account</h3>
            <p className="text-xs text-slate-500 mb-5">Select your bank to fetch UPI handles via NPCI mobile network</p>

            <form onSubmit={handleAddBankSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Select Bank</label>
                <select
                  value={selectedBankTemplate.name}
                  onChange={(e) => {
                    const found = AVAILABLE_BANKS.find((b) => b.name === e.target.value);
                    if (found) setSelectedBankTemplate(found);
                  }}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {AVAILABLE_BANKS.map((b) => (
                    <option key={b.name} value={b.name}>
                      {b.name} ({b.short})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Account Last 4 Digits</label>
                <input
                  type="text"
                  maxLength={4}
                  required
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex gap-2.5 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="w-1/2 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-2xl transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs rounded-2xl shadow-md transition"
                >
                  Fetch & Link Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
