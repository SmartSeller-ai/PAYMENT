'use client';

import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  Download, 
  Fuel, 
  ShoppingCart, 
  Utensils, 
  Carrot, 
  Pill, 
  Zap, 
  ShoppingBag, 
  ArrowRightLeft, 
  MoreHorizontal,
  ArrowUpRight,
  ArrowDownLeft,
  Calendar,
  CheckCircle2,
  Receipt,
  X
} from 'lucide-react';
import { CategoryId, Transaction } from '@/types/upi';
import { CATEGORIES } from '@/lib/categoryData';

interface TransactionHistoryProps {
  transactions: Transaction[];
}

export const TransactionHistory: React.FC<TransactionHistoryProps> = ({
  transactions,
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<CategoryId | 'all'>('all');
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);

  const filtered = transactions.filter((tx) => {
    const matchesCategory = selectedCategory === 'all' || tx.category === selectedCategory;
    const matchesSearch =
      tx.merchantName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.note?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.amount.toString().includes(searchTerm);
    return matchesCategory && matchesSearch;
  });

  const getCategoryIcon = (catId: CategoryId) => {
    switch (catId) {
      case 'petroleum': return Fuel;
      case 'groceries': return ShoppingCart;
      case 'food': return Utensils;
      case 'vegetables': return Carrot;
      case 'pharmacy': return Pill;
      case 'utilities': return Zap;
      case 'shopping': return ShoppingBag;
      case 'transfer': return ArrowRightLeft;
      default: return MoreHorizontal;
    }
  };

  const handleExportCsv = () => {
    const headers = ['ID', 'Date', 'Merchant', 'Category', 'Amount (INR)', 'Type', 'Bank', 'Status', 'Note'];
    const rows = filtered.map((tx) => [
      tx.id,
      new Date(tx.timestamp).toLocaleString('en-IN'),
      `"${tx.merchantName}"`,
      tx.category,
      tx.amount,
      tx.type,
      `"${tx.bankName}"`,
      tx.status,
      `"${tx.note || ''}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `PayMax_UPI_Expenses_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-white rounded-3xl shadow-xs border border-slate-200 p-6 sm:p-7 space-y-5 animate-fade-in">
      {/* Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div>
          <h3 className="font-bold text-lg text-slate-900 flex items-center gap-2">
            <Receipt className="w-5 h-5 text-indigo-600" />
            <span>UPI Statement & Category History</span>
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">Filtered search for fuel, grocery, food & health receipts</p>
        </div>

        <button
          onClick={handleExportCsv}
          className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 px-4 py-2 rounded-2xl text-xs font-bold transition active:scale-95"
        >
          <Download className="w-4 h-4 text-slate-600" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* Filter Row */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative flex-1 min-w-[200px]">
          <input
            type="text"
            placeholder="Search HPCL, Blinkit, Apollo, Swiggy..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-1 overflow-x-auto py-1 max-w-full scrollbar-none">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
              selectedCategory === 'all'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All Categories
          </button>
          {(['petroleum', 'groceries', 'food', 'vegetables', 'pharmacy'] as CategoryId[]).map((catId) => {
            const cat = CATEGORIES[catId];
            const isSelected = selectedCategory === catId;
            return (
              <button
                key={catId}
                onClick={() => setSelectedCategory(catId)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition border ${
                  isSelected
                    ? `${cat.bgColor} ${cat.borderColor} ${cat.textColor} font-bold ring-1`
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                {cat.name.split(' ')[0]}
              </button>
            );
          })}
        </div>
      </div>

      {/* Transaction List */}
      <div className="space-y-2 mt-4">
        {filtered.length === 0 ? (
          <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
            <p className="text-sm font-semibold text-slate-600">No transactions found</p>
            <p className="text-xs text-slate-400 mt-1">Try resetting search filters or log a new payment</p>
          </div>
        ) : (
          filtered.map((tx) => {
            const catMeta = CATEGORIES[tx.category];
            const Icon = getCategoryIcon(tx.category);
            const isDebit = tx.type === 'debit';

            return (
              <div
                key={tx.id}
                onClick={() => setSelectedTx(tx)}
                className="p-3.5 rounded-2xl bg-slate-50/80 hover:bg-slate-100/80 border border-slate-100 hover:border-slate-200 flex items-center justify-between transition cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold shadow-xs shrink-0"
                    style={{ backgroundColor: catMeta?.color || '#64748b' }}
                  >
                    <Icon className="w-5 h-5" />
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-xs sm:text-sm text-slate-900 group-hover:text-indigo-600">
                        {tx.merchantName}
                      </h4>
                      <span
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${catMeta?.bgColor} ${catMeta?.textColor} ${catMeta?.borderColor}`}
                      >
                        {catMeta?.name.split('&')[0]}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-2">
                      <span>{tx.bankName}</span>
                      <span>•</span>
                      <span>{new Date(tx.timestamp).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <p className={`font-black text-sm sm:text-base ${isDebit ? 'text-slate-900' : 'text-emerald-600'}`}>
                    {isDebit ? '-' : '+'}₹{tx.amount.toLocaleString('en-IN')}
                  </p>
                  <span className="text-[10px] text-emerald-600 font-semibold flex items-center justify-end gap-0.5">
                    <CheckCircle2 className="w-3 h-3" /> UPI Success
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Transaction Detail Receipt Modal */}
      {selectedTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-fade-in">
          <div className="bg-white rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl border border-slate-200">
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-sm">UPI Transaction Receipt</h3>
              </div>
              <button
                onClick={() => setSelectedTx(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div className="text-center pb-3 border-b border-slate-100">
                <p className="text-xs text-slate-500">Amount Paid</p>
                <p className="text-3xl font-black text-slate-900 mt-1">₹{selectedTx.amount.toLocaleString('en-IN')}</p>
                <span className="inline-block mt-2 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                  Transaction Successful
                </span>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-50">
                  <span className="text-slate-500">Merchant</span>
                  <span className="font-bold text-slate-800">{selectedTx.merchantName}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-50">
                  <span className="text-slate-500">Category</span>
                  <span className="font-bold text-indigo-600">{CATEGORIES[selectedTx.category]?.name}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-50">
                  <span className="text-slate-500">Bank Account</span>
                  <span className="font-semibold text-slate-800">{selectedTx.bankName}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-50">
                  <span className="text-slate-500">UPI Ref ID</span>
                  <span className="font-mono text-slate-600">UPI/2026/07/{selectedTx.id}</span>
                </div>
                {selectedTx.note && (
                  <div className="flex justify-between py-1">
                    <span className="text-slate-500">Note</span>
                    <span className="font-medium text-slate-800">{selectedTx.note}</span>
                  </div>
                )}
              </div>

              <button
                onClick={() => setSelectedTx(null)}
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition mt-4"
              >
                Close Receipt
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
