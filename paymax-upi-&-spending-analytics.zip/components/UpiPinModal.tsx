'use client';

import React, { useState } from 'react';
import { ShieldCheck, Lock, Delete, X, AlertCircle } from 'lucide-react';
import { BankAccount } from '@/types/upi';

interface UpiPinModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  title: string;
  bankAccount?: BankAccount;
  amount?: number;
  recipientName?: string;
}

export const UpiPinModal: React.FC<UpiPinModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  title,
  bankAccount,
  amount,
  recipientName,
}) => {
  const [pin, setPin] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [isVerifying, setIsVerifying] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleKeyPress = (num: string) => {
    if (pin.length < 6) {
      setError('');
      const newPin = pin + num;
      setPin(newPin);
    }
  };

  const handleDelete = () => {
    setError('');
    setPin(pin.slice(0, -1));
  };

  const handleSubmit = () => {
    if (pin.length !== 4 && pin.length !== 6) {
      setError('Please enter a valid 4 or 6 digit UPI PIN');
      return;
    }

    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      setPin('');
      onSuccess();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 text-white rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl relative">
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-900 via-slate-900 to-slate-900 p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-indigo-500/20 text-indigo-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">{title}</h3>
              <p className="text-xs text-slate-400">NPCI Encrypted UPI Gate</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Transaction Brief */}
        <div className="p-4 bg-slate-950/50 border-b border-slate-800 text-center">
          {bankAccount && (
            <p className="text-xs text-slate-400">
              Debiting <span className="font-semibold text-slate-200">{bankAccount.bankName}</span> ({bankAccount.accountNumber})
            </p>
          )}

          {amount && recipientName && (
            <div className="mt-2">
              <p className="text-xs text-slate-400">Paying to <span className="text-indigo-300 font-medium">{recipientName}</span></p>
              <p className="text-2xl font-extrabold text-emerald-400 mt-1">₹{amount.toLocaleString('en-IN')}</p>
            </div>
          )}
        </div>

        {/* PIN Entry Display */}
        <div className="p-6 text-center">
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-4 flex items-center justify-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-indigo-400" /> Enter UPI PIN
          </p>

          <div className="flex items-center justify-center gap-3 my-4">
            {[0, 1, 2, 3, 4, 5].map((index) => (
              <div
                key={index}
                className={`w-4 h-4 rounded-full border-2 transition-all ${
                  index < pin.length
                    ? 'bg-indigo-500 border-indigo-400 shadow-sm shadow-indigo-500/50 scale-110'
                    : 'border-slate-700 bg-slate-800/50'
                }`}
              />
            ))}
          </div>

          {error && (
            <p className="text-xs text-rose-400 flex items-center justify-center gap-1 mt-2">
              <AlertCircle className="w-3.5 h-3.5" /> {error}
            </p>
          )}
        </div>

        {/* Keypad */}
        <div className="p-4 bg-slate-950 border-t border-slate-800">
          <div className="grid grid-cols-3 gap-2">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
              <button
                key={num}
                onClick={() => handleKeyPress(num)}
                disabled={isVerifying}
                className="py-3 text-lg font-semibold rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-100 active:scale-95 transition"
              >
                {num}
              </button>
            ))}
            <button
              onClick={handleDelete}
              disabled={isVerifying}
              className="py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 flex items-center justify-center active:scale-95 transition"
            >
              <Delete className="w-5 h-5" />
            </button>
            <button
              onClick={() => handleKeyPress('0')}
              disabled={isVerifying}
              className="py-3 text-lg font-semibold rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-100 active:scale-95 transition"
            >
              0
            </button>
            <button
              onClick={handleSubmit}
              disabled={pin.length < 4 || isVerifying}
              className="py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-md active:scale-95 transition disabled:opacity-40 disabled:hover:bg-emerald-600"
            >
              {isVerifying ? '...' : 'SUBMIT'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
