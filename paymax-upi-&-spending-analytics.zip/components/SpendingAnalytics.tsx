'use client';

import React, { useState, useMemo } from 'react';
import { 
  PieChart as PieChartIcon, 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  Filter, 
  Fuel, 
  ShoppingCart, 
  Utensils, 
  Carrot, 
  Pill, 
  Zap, 
  ShoppingBag, 
  ArrowRightLeft, 
  MoreHorizontal,
  Info,
  DollarSign
} from 'lucide-react';
import { 
  PieChart, 
  Pie, 
  Cell, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  Legend 
} from 'recharts';
import { CategoryId, Transaction } from '@/types/upi';
import { CATEGORIES } from '@/lib/categoryData';

interface SpendingAnalyticsProps {
  transactions: Transaction[];
  onSelectCategoryFilter?: (catId: CategoryId | 'all') => void;
}

export const SpendingAnalytics: React.FC<SpendingAnalyticsProps> = ({
  transactions,
  onSelectCategoryFilter,
}) => {
  const [selectedTimeframe, setSelectedTimeframe] = useState<'this_month' | 'last_month' | 'all'>('this_month');
  const [activeBankFilter, setActiveBankFilter] = useState<string>('all');

  // Filter transactions
  const filteredTx = useMemo(() => {
    return transactions.filter((tx) => {
      if (tx.type !== 'debit') return false; // Only calculate expenses
      if (activeBankFilter !== 'all' && tx.bankAccountId !== activeBankFilter) return false;
      return true;
    });
  }, [transactions, activeBankFilter]);

  // Total expense
  const totalExpense = useMemo(() => {
    return filteredTx.reduce((sum, tx) => sum + tx.amount, 0);
  }, [filteredTx]);

  // Aggregate by category
  const categoryTotals = useMemo(() => {
    const map: Record<CategoryId, number> = {
      petroleum: 0,
      groceries: 0,
      food: 0,
      vegetables: 0,
      pharmacy: 0,
      utilities: 0,
      shopping: 0,
      transfer: 0,
      other: 0,
    };

    filteredTx.forEach((tx) => {
      map[tx.category] = (map[tx.category] || 0) + tx.amount;
    });

    return Object.entries(map)
      .map(([catId, amount]) => {
        const meta = CATEGORIES[catId as CategoryId];
        const percentage = totalExpense > 0 ? (amount / totalExpense) * 100 : 0;
        return {
          id: catId as CategoryId,
          name: meta?.name || catId,
          shortName: meta?.name.split('&')[0] || catId,
          value: amount,
          percentage: parseFloat(percentage.toFixed(1)),
          color: meta?.color || '#64748b',
          icon: meta?.iconName,
        };
      })
      .filter((item) => item.value > 0)
      .sort((a, b) => b.value - a.value);
  }, [filteredTx, totalExpense]);

  // Aggregate by day for bar chart
  const dailyData = useMemo(() => {
    const dayMap: Record<string, number> = {};

    filteredTx.forEach((tx) => {
      const dateStr = new Date(tx.timestamp).toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
      });
      dayMap[dateStr] = (dayMap[dateStr] || 0) + tx.amount;
    });

    return Object.entries(dayMap)
      .map(([date, amount]) => ({ date, amount }))
      .slice(-10); // Last 10 active dates
  }, [filteredTx]);

  const getCategoryIcon = (catId: CategoryId) => {
    switch (catId) {
      case 'petroleum': return Fuel;
      case 'groceries': return ShoppingCart;
      case 'food': return Utensils;
      case 'vegetables': return Carrot;
      case 'pharmacy': return Pill;
      case 'utilities': return Zap;
      case 'shopping': return ShoppingBag;
      case 'transfer': return ArrowRightLeft;
      default: return MoreHorizontal;
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Stat Cards - Bento Grid 4 Cols */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Expense Card */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Total Category Expenses
            </span>
            <div className="p-2.5 rounded-2xl bg-indigo-50 text-indigo-600">
              <PieChartIcon className="w-5 h-5" />
            </div>
          </div>
          <p className="text-3xl font-black text-slate-900 mt-3">
            ₹{totalExpense.toLocaleString('en-IN')}
          </p>
          <p className="text-xs text-slate-500 mt-1 flex items-center gap-1 font-medium">
            <TrendingUp className="w-3.5 h-3.5 text-rose-500" />
            <span>Across all linked bank accounts</span>
          </p>
        </div>

        {/* Petroleum Focus */}
        <div className="bg-gradient-to-br from-amber-50 to-orange-50/70 p-6 rounded-3xl border border-amber-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-800">
              ⛽ Petroleum / Fuel
            </span>
            <Fuel className="w-5 h-5 text-amber-600" />
          </div>
          <p className="text-3xl font-black text-amber-950 mt-3">
            ₹{(categoryTotals.find((c) => c.id === 'petroleum')?.value || 0).toLocaleString('en-IN')}
          </p>
          <p className="text-xs text-amber-700 mt-1 font-bold">
            {categoryTotals.find((c) => c.id === 'petroleum')?.percentage || 0}% of total spend
          </p>
        </div>

        {/* Groceries & Veg Focus */}
        <div className="bg-gradient-to-br from-emerald-50 to-lime-50/70 p-6 rounded-3xl border border-emerald-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-800">
              🛒 Groceries & Veggies
            </span>
            <div className="flex items-center gap-1">
              <ShoppingCart className="w-4 h-4 text-emerald-600" />
              <Carrot className="w-4 h-4 text-lime-600" />
            </div>
          </div>
          <p className="text-3xl font-black text-emerald-950 mt-3">
            ₹{(
              (categoryTotals.find((c) => c.id === 'groceries')?.value || 0) +
              (categoryTotals.find((c) => c.id === 'vegetables')?.value || 0)
            ).toLocaleString('en-IN')}
          </p>
          <p className="text-xs text-emerald-700 mt-1 font-bold">
            Food staples & fresh produce
          </p>
        </div>

        {/* Pharmacy & Health Focus */}
        <div className="bg-gradient-to-br from-cyan-50 to-sky-50/70 p-6 rounded-3xl border border-cyan-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-800">
              💊 Pharmacy & Health
            </span>
            <Pill className="w-5 h-5 text-cyan-600" />
          </div>
          <p className="text-3xl font-black text-cyan-950 mt-3">
            ₹{(categoryTotals.find((c) => c.id === 'pharmacy')?.value || 0).toLocaleString('en-IN')}
          </p>
          <p className="text-xs text-cyan-700 mt-1 font-bold">
            Medicines, labs & wellness
          </p>
        </div>
      </div>

      {/* Charts Grid - Bento Style */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Category Breakdown Donut Chart (7 Cols) */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <PieChartIcon className="w-5 h-5 text-indigo-600" />
                <span>Category Expense Breakdown</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">Distribution of spent amount in Indian Rupees (₹)</p>
            </div>

            {/* Filter Pills */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-2xl text-xs font-bold">
              <button
                onClick={() => setSelectedTimeframe('this_month')}
                className={`px-3 py-1.5 rounded-xl transition ${
                  selectedTimeframe === 'this_month'
                    ? 'bg-white text-indigo-700 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                This Month
              </button>
              <button
                onClick={() => setSelectedTimeframe('all')}
                className={`px-3 py-1.5 rounded-xl transition ${
                  selectedTimeframe === 'all'
                    ? 'bg-white text-indigo-700 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All Time
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center mt-4">
            {/* Recharts Donut */}
            <div className="md:col-span-6 h-64 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryTotals}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={95}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {categoryTotals.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: any) => [`₹${Number(value).toLocaleString('en-IN')}`, 'Spent']}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Legend & List */}
            <div className="md:col-span-6 space-y-2 max-h-64 overflow-y-auto pr-1">
              {categoryTotals.map((item) => {
                const Icon = getCategoryIcon(item.id);
                return (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-2.5 rounded-2xl bg-slate-50 hover:bg-slate-100/80 border border-slate-100 transition text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <div
                        className="w-3 h-3 rounded-full shrink-0"
                        style={{ backgroundColor: item.color }}
                      />
                      <Icon className="w-3.5 h-3.5 text-slate-600" />
                      <span className="font-bold text-slate-800">{item.shortName}</span>
                    </div>

                    <div className="text-right">
                      <span className="font-black text-slate-900">₹{item.value.toLocaleString('en-IN')}</span>
                      <span className="text-[10px] text-slate-500 block font-mono font-semibold">{item.percentage}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Daily Spending Trend Bar Chart (5 Cols) */}
        <div className="lg:col-span-5 bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
          <div className="pb-4 border-b border-slate-100">
            <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-indigo-600" />
              <span>Daily Spend Trend</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">Expenses logged over recent days</p>
          </div>

          <div className="h-64 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dailyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#64748b' }} />
                <YAxis tick={{ fontSize: 10, fill: '#64748b' }} />
                <Tooltip
                  formatter={(value: any) => [`₹${Number(value).toLocaleString('en-IN')}`, 'Daily Spend']}
                />
                <Bar dataKey="amount" fill="#4f46e5" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
