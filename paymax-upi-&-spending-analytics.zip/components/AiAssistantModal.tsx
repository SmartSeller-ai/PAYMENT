'use client';

import React, { useState } from 'react';
import { 
  Bot, 
  Sparkles, 
  Scan, 
  Upload, 
  FileText, 
  TrendingUp, 
  AlertCircle, 
  CheckCircle2, 
  Lightbulb, 
  Send,
  Loader2,
  DollarSign
} from 'lucide-react';
import { CategoryId, Transaction, CategoryBudget } from '@/types/upi';
import { CATEGORIES } from '@/lib/categoryData';

interface AiAssistantModalProps {
  transactions: Transaction[];
  budgets: CategoryBudget[];
  onAutoAddTransaction: (data: {
    merchantName: string;
    vpa: string;
    amount: number;
    category: CategoryId;
    note: string;
  }) => void;
}

export const AiAssistantModal: React.FC<AiAssistantModalProps> = ({
  transactions,
  budgets,
  onAutoAddTransaction,
}) => {
  const [activeTab, setActiveTab] = useState<'scan' | 'advisor'>('scan');
  
  // Scan State
  const [receiptText, setReceiptText] = useState<string>('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanResult, setScanResult] = useState<any>(null);
  const [scanError, setScanError] = useState<string>('');

  // Advisor State
  const [isAdvisorLoading, setIsAdvisorLoading] = useState<boolean>(false);
  const [advisorData, setAdvisorData] = useState<any>(null);

  // Quick Preset Sample Bills
  const SAMPLE_BILLS = [
    {
      title: 'HPCL Petrol Pump Bill',
      text: 'HPCL AUTO CARE station #420. Petrol Power 95 liters: 18.5L @ 102.50 = Total Rs 1,896.25. Paid via UPI.',
    },
    {
      title: 'Blinkit Quick Grocery Receipt',
      text: 'Blinkit Order #ZEP-882. Aashirvaad Atta 5kg (Rs 280), Amul Butter 500g (Rs 275), Fortune Oil 1L (Rs 165). Total: Rs 720.',
    },
    {
      title: 'Apollo Pharmacy Medical Bill',
      text: 'Apollo Pharmacy Store #112. Crocin Advance 650 (Rs 45), Shellcal HD (Rs 230), Revital H (Rs 410). Total Rs 685.',
    },
    {
      title: 'Local Sabzi Mandi Vegetables',
      text: 'GreenFresh Vegetable Mandi Stall. 2kg Tomato Rs 60, 1kg Onion Rs 40, Spinach 2 bunches Rs 30, Cauliflower Rs 50. Total Rs 180.',
    },
  ];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyzeReceipt = async () => {
    if (!receiptText && !selectedImage) return;

    setIsScanning(true);
    setScanError('');
    setScanResult(null);

    try {
      const base64Data = selectedImage ? selectedImage.split(',')[1] : null;
      const mimeType = selectedImage ? selectedImage.split(';')[0].split(':')[1] : null;

      const res = await fetch('/api/gemini/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          receiptText,
          imageBase64: base64Data,
          imageMimeType: mimeType,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setScanResult(data);
      } else {
        setScanError(data.error || 'Failed to analyze bill.');
      }
    } catch (err: any) {
      setScanError(err.message || 'Error communicating with Gemini AI.');
    } finally {
      setIsScanning(false);
    }
  };

  const handleConfirmAutoAdd = () => {
    if (!scanResult) return;

    onAutoAddTransaction({
      merchantName: scanResult.merchantName || 'Scanned Merchant',
      vpa: `${scanResult.merchantName?.toLowerCase().replace(/\s+/g, '') || 'pay'}@icici`,
      amount: scanResult.amount || 0,
      category: (scanResult.category as CategoryId) || 'other',
      note: scanResult.note || 'Scanned Bill',
    });

    setScanResult(null);
    setReceiptText('');
    setSelectedImage(null);
  };

  const handleGetAdvisorAdvice = async () => {
    setIsAdvisorLoading(true);

    // Prepare category totals
    const categoryTotals: Record<string, number> = {};
    let totalSpent = 0;

    transactions.forEach((tx) => {
      if (tx.type === 'debit') {
        categoryTotals[tx.category] = (categoryTotals[tx.category] || 0) + tx.amount;
        totalSpent += tx.amount;
      }
    });

    try {
      const res = await fetch('/api/gemini/advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          categoryTotals,
          budgets,
          totalSpent,
        }),
      });

      const data = await res.json();
      setAdvisorData(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsAdvisorLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-3xl shadow-xs border border-slate-200 p-6 sm:p-7 space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
            <Bot className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <span>Gemini AI Financial Assistant</span>
              <span className="text-[10px] font-black px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-700 uppercase">
                Gemini 2.5
              </span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">Scan receipts, auto-categorize expenses & get smart savings advice</p>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-2xl text-xs font-bold">
          <button
            onClick={() => setActiveTab('scan')}
            className={`px-3.5 py-2 rounded-xl transition ${
              activeTab === 'scan' ? 'bg-white text-indigo-700 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Scan className="w-4 h-4 inline mr-1" /> Bill & Receipt Scanner
          </button>
          <button
            onClick={() => {
              setActiveTab('advisor');
              if (!advisorData) handleGetAdvisorAdvice();
            }}
            className={`px-3.5 py-2 rounded-xl transition ${
              activeTab === 'advisor' ? 'bg-white text-indigo-700 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-4 h-4 inline mr-1" /> Spending Advisor
          </button>
        </div>
      </div>

      {/* Tab 1: Receipt Scanner */}
      {activeTab === 'scan' && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Input Side */}
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-700 mb-1.5">
                  Paste Bill / Receipt Text
                </label>
                <textarea
                  rows={4}
                  placeholder="Paste bill details, e.g. HPCL petrol 18.5L Rs 1896, or Blinkit grocery Rs 720..."
                  value={receiptText}
                  onChange={(e) => setReceiptText(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Sample Preset Buttons */}
              <div>
                <p className="text-[11px] font-semibold text-slate-500 uppercase mb-1.5">Try Sample Bill Notes:</p>
                <div className="grid grid-cols-1 gap-1.5">
                  {SAMPLE_BILLS.map((sample, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setReceiptText(sample.text)}
                      className="p-2 bg-slate-50 hover:bg-indigo-50 border border-slate-200 hover:border-indigo-200 rounded-xl text-left text-xs transition"
                    >
                      <span className="font-bold text-slate-900 block">{sample.title}</span>
                      <span className="text-[11px] text-slate-500 line-clamp-1">{sample.text}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Image Upload Option */}
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-700 mb-1">
                  Or Upload Receipt Photo
                </label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="block w-full text-xs text-slate-500 file:mr-3 file:py-2 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 cursor-pointer"
                />
                {selectedImage && (
                  <p className="text-[11px] text-emerald-600 mt-1 font-semibold">✓ Image loaded ready to scan</p>
                )}
              </div>

              <button
                onClick={handleAnalyzeReceipt}
                disabled={(!receiptText && !selectedImage) || isScanning}
                className="w-full py-3 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white font-bold text-xs rounded-xl shadow-md transition disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isScanning ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Gemini AI Analyzing Bill...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Scan & Auto-Categorize with Gemini</span>
                  </>
                )}
              </button>
            </div>

            {/* Results Side */}
            <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 min-h-[250px] flex flex-col justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-900 mb-2 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>AI Extraction Result</span>
                </h3>

                {scanError && (
                  <p className="text-xs text-rose-600 p-3 bg-rose-50 rounded-xl border border-rose-200">
                    {scanError}
                  </p>
                )}

                {!scanResult && !isScanning && !scanError && (
                  <div className="text-center py-10 text-slate-400 space-y-2">
                    <Bot className="w-10 h-10 mx-auto text-slate-300" />
                    <p className="text-xs">Paste bill text or upload receipt photo on the left to extract details.</p>
                  </div>
                )}

                {scanResult && (
                  <div className="space-y-3 mt-3 text-xs bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Extracted Merchant:</span>
                      <span className="font-bold text-slate-900">{scanResult.merchantName}</span>
                    </div>

                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Detected Amount:</span>
                      <span className="font-extrabold text-emerald-600 text-base">₹{scanResult.amount}</span>
                    </div>

                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Auto-Assigned Category:</span>
                      <span className="font-bold text-indigo-600 uppercase">
                        {CATEGORIES[scanResult.category as CategoryId]?.name || scanResult.category}
                      </span>
                    </div>

                    <div className="flex justify-between py-1">
                      <span className="text-slate-500">Note:</span>
                      <span className="font-medium text-slate-800">{scanResult.note}</span>
                    </div>
                  </div>
                )}
              </div>

              {scanResult && (
                <button
                  onClick={handleConfirmAutoAdd}
                  className="w-full mt-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition"
                >
                  Confirm & Auto-Log Payment
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: AI Spending Advisor */}
      {activeTab === 'advisor' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-900">Personalized Category Insights & Savings Advisor</h3>
            <button
              onClick={handleGetAdvisorAdvice}
              disabled={isAdvisorLoading}
              className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-semibold transition flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5" /> Refresh Insights
            </button>
          </div>

          {isAdvisorLoading ? (
            <div className="p-8 text-center bg-slate-50 rounded-2xl">
              <Loader2 className="w-8 h-8 text-indigo-600 animate-spin mx-auto mb-2" />
              <p className="text-xs font-semibold text-slate-700">Gemini AI is analyzing Petroleum, Grocery, and Food expenses...</p>
            </div>
          ) : advisorData ? (
            <div className="space-y-4">
              {/* Headline Banner */}
              <div className="bg-gradient-to-r from-indigo-900 via-slate-900 to-purple-950 p-4 rounded-2xl text-white shadow-md">
                <h4 className="font-extrabold text-base mb-1">{advisorData.summaryHeadline}</h4>
                <p className="text-xs text-indigo-200">
                  Estimated potential monthly savings: <span className="font-black text-amber-300">₹{advisorData.projectedSavings}</span>
                </p>
              </div>

              {/* Alerts Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {advisorData.categoryAlerts?.map((alert: any, idx: number) => (
                  <div
                    key={idx}
                    className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900 uppercase">
                        {CATEGORIES[alert.category as CategoryId]?.name || alert.category}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                          alert.status === 'warning'
                            ? 'bg-amber-100 text-amber-800'
                            : alert.status === 'exceeded'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {alert.status}
                      </span>
                    </div>
                    <p className="text-slate-600">{alert.message}</p>
                  </div>
                ))}
              </div>

              {/* Savings Tips List */}
              <div className="p-4 bg-indigo-50/70 border border-indigo-200 rounded-2xl space-y-2">
                <h4 className="font-bold text-xs text-indigo-900 flex items-center gap-1.5">
                  <Lightbulb className="w-4 h-4 text-amber-500" /> Actionable Money Saving Tips for India
                </h4>
                <ul className="space-y-2">
                  {advisorData.actionableTips?.map((tip: string, idx: number) => (
                    <li key={idx} className="text-xs text-indigo-950 flex items-start gap-2">
                      <span className="text-indigo-600 font-bold">•</span>
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ) : null}
        </div>
      )}
    </div>
  );
};
