'use client';

import React, { useState } from 'react';
import { Gift, Sparkles, CheckCircle, Fuel, ShoppingCart, Pill, ShieldCheck } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Reward } from '@/types/upi';

interface RewardsSectionProps {
  rewards: Reward[];
  onScratchReward: (rewardId: string) => void;
}

export const RewardsSection: React.FC<RewardsSectionProps> = ({
  rewards,
  onScratchReward,
}) => {
  const [scratchingId, setScratchingId] = useState<string | null>(null);

  const handleScratch = (reward: Reward) => {
    if (reward.isScratched) return;

    setScratchingId(reward.id);

    // Confetti effect
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#6366f1', '#10b981', '#f59e0b', '#ec4899'],
      });
    } catch (e) {
      console.log('Confetti error:', e);
    }

    setTimeout(() => {
      onScratchReward(reward.id);
      setScratchingId(null);
    }, 600);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-white rounded-3xl shadow-xs border border-slate-200 p-6 sm:p-7">
        <div className="flex items-center justify-between pb-4 mb-5 border-b border-slate-100">
          <div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <Gift className="w-5 h-5 text-indigo-600" />
              <span>UPI Cashback Scratch Cards & Offers</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Earned on Petroleum refills, Grocery, and Pharmacy payments
            </p>
          </div>

          <span className="px-3.5 py-1.5 bg-amber-100 text-amber-900 text-xs font-black rounded-full flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-amber-600" />
            {rewards.filter((r) => !r.isScratched).length} Unscratched
          </span>
        </div>

        {/* Scratch Cards Grid - Bento Layout */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {rewards.map((reward) => (
            <div
              key={reward.id}
              onClick={() => handleScratch(reward)}
              className={`rounded-3xl p-6 border transition-all cursor-pointer relative overflow-hidden ${
                reward.isScratched
                  ? 'bg-gradient-to-br from-emerald-50 via-teal-50 to-white border-emerald-200 shadow-xs'
                  : 'bg-slate-900 border-slate-800 text-white shadow-md hover:scale-[1.02]'
              }`}
            >
              {!reward.isScratched ? (
                /* Unscratched Front Cover */
                <div className="text-center py-6 space-y-3">
                  <div className="w-14 h-14 mx-auto rounded-full bg-gradient-to-tr from-amber-400 to-yellow-300 p-0.5 shadow-md flex items-center justify-center animate-bounce-slow">
                    <div className="w-full h-full bg-slate-950 rounded-full flex items-center justify-center">
                      <Gift className="w-7 h-7 text-amber-400" />
                    </div>
                  </div>
                  <div>
                    <h3 className="font-bold text-base text-white">{reward.merchant}</h3>
                    <p className="text-xs text-indigo-200 mt-1">Tap to Scratch & Reveal Cashback!</p>
                  </div>
                  <span className="inline-block px-3 py-1 bg-amber-400 text-slate-950 font-black text-xs rounded-full shadow-sm">
                    SCRATCH HERE
                  </span>
                </div>
              ) : (
                /* Scratched Revealed Card */
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold uppercase text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full">
                      ✓ Cashback Credited
                    </span>
                    <CheckCircle className="w-5 h-5 text-emerald-600" />
                  </div>

                  <div>
                    <p className="text-xs text-slate-500">{reward.merchant}</p>
                    <h3 className="text-2xl font-black text-slate-900 mt-0.5">₹{reward.cashbackAmount}</h3>
                    <p className="text-xs text-emerald-700 font-semibold mt-1">
                      Directly added to your primary bank account!
                    </p>
                  </div>

                  <div className="pt-3 border-t border-emerald-100 flex items-center justify-between text-xs">
                    <span className="font-mono text-slate-600 font-bold">{reward.code}</span>
                    <span className="text-[10px] text-slate-400">Claimed</span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
