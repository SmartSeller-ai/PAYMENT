import { GoogleGenAI, Type } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const { receiptText, imageBase64, imageMimeType } = await req.json();

    if (!receiptText && !imageBase64) {
      return NextResponse.json(
        { error: 'Please provide receipt text or an image to analyze.' },
        { status: 400 }
      );
    }

    const ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const systemInstruction = `You are an expert AI Indian UPI Expense Scanner & Categorizer.
Given a receipt photo or bill text description, analyze the merchant name, total amount in Indian Rupees (₹), primary category, and short note.

Allowed categories strictly MUST be one of:
- 'petroleum' (fuel, petrol, diesel, gas station, oil, Shell, HPCL, BPCL, IOCL)
- 'groceries' (supermarket, Blinkit, Zepto, BigBasket, Reliance Smart, staples, milk)
- 'food' (restaurant, Swiggy, Zomato, cafe, bakery, dining out)
- 'vegetables' (mandi, local veggie vendor, fruit stall, organic produce)
- 'pharmacy' (Apollo, PharmEasy, MedPlus, medicines, clinic, lab tests)
- 'utilities' (electricity, water, broadband, gas cylinder)
- 'shopping' (Amazon, Flipkart, clothing, shoes, gadgets)
- 'transfer' (rent, send to friend, peer payment)
- 'other' (miscellaneous)`;

    const parts: any[] = [];

    if (imageBase64) {
      parts.push({
        inlineData: {
          data: imageBase64,
          mimeType: imageMimeType || 'image/jpeg',
        },
      });
      parts.push({
        text: 'Extract the merchant name, total bill amount in INR (₹), category, and brief items summary from this receipt.',
      });
    } else {
      parts.push({
        text: `Analyze this transaction/receipt note: "${receiptText}". Extract merchant name, total amount in INR (₹), best category, and brief note.`,
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: { parts },
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            merchantName: { type: Type.STRING },
            amount: { type: Type.NUMBER },
            category: { type: Type.STRING },
            note: { type: Type.STRING },
            confidence: { type: Type.NUMBER },
          },
          required: ['merchantName', 'amount', 'category', 'note'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return NextResponse.json(parsed);
  } catch (error: any) {
    console.error('Gemini Receipt Analyzer Error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to analyze receipt.' },
      { status: 500 }
    );
  }
}
