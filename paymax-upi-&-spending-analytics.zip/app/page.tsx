'use client';

import React, { useState, useMemo } from 'react';
import { Navbar } from '@/components/Navbar';
import { PaymentSection } from '@/components/PaymentSection';
import { SpendingAnalytics } from '@/components/SpendingAnalytics';
import { CategoryBudgets } from '@/components/CategoryBudgets';
import { LinkedBanksSection } from '@/components/LinkedBanksSection';
import { TransactionHistory } from '@/components/TransactionHistory';
import { RewardsSection } from '@/components/RewardsSection';
import { AiAssistantModal } from '@/components/AiAssistantModal';
import { UpiPinModal } from '@/components/UpiPinModal';
import { QrScannerModal } from '@/components/QrScannerModal';

import { BankAccount, CategoryBudget, CategoryId, Reward, Transaction } from '@/types/upi';
import { INITIAL_BANKS, INITIAL_BUDGETS, INITIAL_REWARDS, INITIAL_TRANSACTIONS } from '@/lib/mockData';
import { CATEGORIES } from '@/lib/categoryData';

export default function Home() {
  const [banks, setBanks] = useState<BankAccount[]>(INITIAL_BANKS);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [budgets, setBudgets] = useState<CategoryBudget[]>(INITIAL_BUDGETS);
  const [rewards, setRewards] = useState<Reward[]>(INITIAL_REWARDS);
  const [activeTab, setActiveTab] = useState<string>('pay');

  // Modal State
  const [isPinModalOpen, setIsPinModalOpen] = useState<boolean>(false);
  const [pinModalConfig, setPinModalConfig] = useState<{
    title: string;
    bankAccount?: BankAccount;
    amount?: number;
    recipientName?: string;
    onSuccess: () => void;
  }>({
    title: 'Verify UPI PIN',
    onSuccess: () => {},
  });

  const [isQrModalOpen, setIsQrModalOpen] = useState<boolean>(false);

  // Active Primary Bank
  const primaryBank = useMemo(() => {
    return banks.find((b) => b.isPrimary) || banks[0];
  }, [banks]);

  // Calculate total monthly expenses
  const totalMonthlySpent = useMemo(() => {
    return transactions
      .filter((tx) => tx.type === 'debit')
      .reduce((sum, tx) => sum + tx.amount, 0);
  }, [transactions]);

  // Handler: Set Primary Bank
  const handleSelectPrimaryBank = (bankId: string) => {
    setBanks((prev) =>
      prev.map((b) => ({
        ...b,
        isPrimary: b.id === bankId,
      }))
    );
  };

  // Handler: Add New Bank
  const handleAddNewBank = (newBankData: Omit<BankAccount, 'id'>) => {
    const newBank: BankAccount = {
      ...newBankData,
      id: `bank_${Date.now()}`,
    };
    setBanks((prev) => [...prev, newBank]);
  };

  // Handler: Check Balance PIN Prompt
  const handleOpenCheckBalanceModal = (bank: BankAccount) => {
    setPinModalConfig({
      title: 'Check Bank Account Balance',
      bankAccount: bank,
      onSuccess: () => {
        setIsPinModalOpen(false);
      },
    });
    setIsPinModalOpen(true);
  };

  // Handler: Initiate Payment Flow
  const handleInitiatePayment = (data: {
    merchantName: string;
    vpa: string;
    amount: number;
    category: CategoryId;
    bankAccountId: string;
    note: string;
  }) => {
    const bank = banks.find((b) => b.id === data.bankAccountId) || primaryBank;

    setPinModalConfig({
      title: 'Authorize UPI Payment',
      bankAccount: bank,
      amount: data.amount,
      recipientName: data.merchantName,
      onSuccess: () => {
        setIsPinModalOpen(false);
        executePayment(data, bank);
      },
    });

    setIsPinModalOpen(true);
  };

  // Execute Actual Payment
  const executePayment = (
    data: {
      merchantName: string;
      vpa: string;
      amount: number;
      category: CategoryId;
      bankAccountId: string;
      note: string;
    },
    bank: BankAccount
  ) => {
    // 1. Deduct balance from bank
    setBanks((prev) =>
      prev.map((b) => {
        if (b.id === bank.id) {
          return { ...b, balance: Math.max(0, b.balance - data.amount) };
        }
        return b;
      })
    );

    // 2. Add transaction
    const newTx: Transaction = {
      id: `tx_${Date.now()}`,
      timestamp: new Date().toISOString(),
      merchantName: data.merchantName,
      upiId: data.vpa,
      amount: data.amount,
      type: 'debit',
      category: data.category,
      bankAccountId: bank.id,
      bankName: bank.bankName,
      status: 'success',
      note: data.note,
      receiptNumber: `UPI-${Math.floor(100000 + Math.random() * 900000)}`,
    };

    setTransactions((prev) => [newTx, ...prev]);

    // 3. Generate reward scratch card if fuel, grocery, or pharmacy payment!
    if (['petroleum', 'groceries', 'pharmacy', 'food', 'vegetables'].includes(data.category)) {
      const cashbackAmt = data.category === 'petroleum' ? 50 : data.category === 'pharmacy' ? 100 : 35;
      const newReward: Reward = {
        id: `rew_${Date.now()}`,
        title: `₹${cashbackAmt} Cashback Reward`,
        merchant: data.merchantName,
        category: data.category,
        code: `${data.category.toUpperCase()}${Math.floor(100 + Math.random() * 900)}`,
        cashbackAmount: cashbackAmt,
        isScratched: false,
        dateAdded: new Date().toISOString(),
      };
      setRewards((prev) => [newReward, ...prev]);
    }
  };

  // Handler: QR Code Scanned
  const handleQrScanSuccess = (qrData: {
    merchantName: string;
    vpa: string;
    amount: number;
    category: CategoryId;
    note: string;
  }) => {
    handleInitiatePayment({
      merchantName: qrData.merchantName,
      vpa: qrData.vpa,
      amount: qrData.amount,
      category: qrData.category,
      bankAccountId: primaryBank.id,
      note: qrData.note,
    });
  };

  // Handler: Update Budget Limit
  const handleUpdateBudget = (categoryId: CategoryId, newLimit: number) => {
    setBudgets((prev) =>
      prev.map((b) => (b.categoryId === categoryId ? { ...b, limit: newLimit } : b))
    );
  };

  // Handler: Scratch Reward
  const handleScratchReward = (rewardId: string) => {
    const reward = rewards.find((r) => r.id === rewardId);
    if (reward && !reward.isScratched) {
      setRewards((prev) =>
        prev.map((r) => (r.id === rewardId ? { ...r, isScratched: true } : r))
      );
      // Credit cashback to primary bank balance
      setBanks((prev) =>
        prev.map((b) =>
          b.id === primaryBank.id ? { ...b, balance: b.balance + reward.cashbackAmount } : b
        )
      );
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-16 font-sans">
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        banks={banks}
        primaryBank={primaryBank}
        onOpenBankModal={() => setActiveTab('banks')}
        onOpenCheckBalanceModal={handleOpenCheckBalanceModal}
        totalMonthlySpent={totalMonthlySpent}
      />

      {/* Main Content Area - Bento Grid Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Top Bento Stats Ribbon */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
          <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
            <div>
              <p className="text-[10px] sm:text-xs font-bold text-slate-400 uppercase tracking-wider">
                Monthly Spend
              </p>
              <p className="text-lg sm:text-2xl font-black text-slate-900 mt-1">
                ₹{totalMonthlySpent.toLocaleString('en-IN')}
              </p>
            </div>
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
              ₹
            </div>
          </div>

          <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
            <div>
              <p className="text-[10px] sm:text-xs font-bold text-slate-400 uppercase tracking-wider">
                Active Bank VPA
              </p>
              <p className="text-sm sm:text-base font-bold text-slate-900 mt-1 truncate max-w-[120px] sm:max-w-none">
                {primaryBank?.vpa}
              </p>
            </div>
            <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
              ✓
            </div>
          </div>

          <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
            <div>
              <p className="text-[10px] sm:text-xs font-bold text-slate-400 uppercase tracking-wider">
                Rewards Claimed
              </p>
              <p className="text-lg sm:text-2xl font-black text-amber-600 mt-1">
                ₹{rewards.filter(r => r.isScratched).reduce((acc, r) => acc + r.cashbackAmount, 0)}
              </p>
            </div>
            <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
              🎁
            </div>
          </div>

          <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
            <div>
              <p className="text-[10px] sm:text-xs font-bold text-slate-400 uppercase tracking-wider">
                AI Budget Score
              </p>
              <p className="text-lg sm:text-2xl font-black text-indigo-600 mt-1">
                94 / 100
              </p>
            </div>
            <div className="w-10 h-10 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold">
              ⚡
            </div>
          </div>
        </div>

        {/* Tab 1: Pay & Send */}
        {activeTab === 'pay' && (
          <div className="space-y-8">
            <PaymentSection
              banks={banks}
              primaryBank={primaryBank}
              onInitiatePayment={handleInitiatePayment}
              onOpenQrScanner={() => setIsQrModalOpen(true)}
            />
            <TransactionHistory transactions={transactions} />
          </div>
        )}

        {/* Tab 2: Spending Analytics */}
        {activeTab === 'analytics' && (
          <div className="space-y-8">
            <SpendingAnalytics transactions={transactions} />
            <TransactionHistory transactions={transactions} />
          </div>
        )}

        {/* Tab 3: Budgets & Categories */}
        {activeTab === 'categories' && (
          <CategoryBudgets
            budgets={budgets}
            transactions={transactions}
            onUpdateBudget={handleUpdateBudget}
          />
        )}

        {/* Tab 4: Linked Banks */}
        {activeTab === 'banks' && (
          <LinkedBanksSection
            banks={banks}
            primaryBank={primaryBank}
            onSelectPrimaryBank={handleSelectPrimaryBank}
            onOpenCheckBalanceModal={handleOpenCheckBalanceModal}
            onAddNewBank={handleAddNewBank}
          />
        )}

        {/* Tab 5: Rewards & Offers */}
        {activeTab === 'rewards' && (
          <RewardsSection
            rewards={rewards}
            onScratchReward={handleScratchReward}
          />
        )}

        {/* Tab 6: AI Scanner & Advisor */}
        {activeTab === 'ai' && (
          <AiAssistantModal
            transactions={transactions}
            budgets={budgets}
            onAutoAddTransaction={(data) => {
              handleInitiatePayment({
                ...data,
                bankAccountId: primaryBank.id,
              });
            }}
          />
        )}
      </main>

      {/* Global Modals */}
      <UpiPinModal
        isOpen={isPinModalOpen}
        onClose={() => setIsPinModalOpen(false)}
        onSuccess={pinModalConfig.onSuccess}
        title={pinModalConfig.title}
        bankAccount={pinModalConfig.bankAccount}
        amount={pinModalConfig.amount}
        recipientName={pinModalConfig.recipientName}
      />

      <QrScannerModal
        isOpen={isQrModalOpen}
        onClose={() => setIsQrModalOpen(false)}
        onScanSuccess={handleQrScanSuccess}
      />
    </div>
  );
}
