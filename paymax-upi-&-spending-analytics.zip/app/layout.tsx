import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'PayMax UPI - Multi-Bank Payments & Category Spending Analytics',
  description: 'Seamless UPI payments across multiple banks with smart category-wise spending analytics for Petroleum, Groceries, Food, Vegetables, Pharmacy, and more.',
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
